Install Instructions:

1. In the installer folder located in this directy, run setup.exe
2. The destination for the instillation MUST be the root of the HackNSlashBuild folder
3. Once installed, you MUST run the game as an administrator by right clicking on the HackNSlash.exe and clicking Run as administrator